<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>가입완료</title>
    <style type="text/css">
        body{font-size:16px}
        a{text-decoration:none;color:rgb(0, 132, 255)}
        a:hover{color:rgb(255, 153, 0)}
    </style>
</head>
<body>
    <h2>* 가입이 완료되었습니다.</h2>
    <p>사이트의 모든 서비스를 제공 받으실 수 있습니다.</p>
    <p>
        <a href="../index.php">메인 페이지로</a>
        <a href="../login/login.php">로그인</a>
    </p>
</body>
</html>